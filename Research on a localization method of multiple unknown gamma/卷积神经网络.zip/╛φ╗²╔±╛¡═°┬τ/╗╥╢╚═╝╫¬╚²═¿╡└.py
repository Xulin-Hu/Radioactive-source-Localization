# import cv2
# import os
# from PIL import Image
# import numpy as np
# file_dir = "C:/Users/胡/Desktop/能量沉积/test三通道/"
# out_dir = "C:/Users/胡/Desktop/能量沉积/RGB/"
# a = os.listdir(file_dir)
#
# for i in a:
#     print(i)
#     I = Image.open(file_dir + i)
#     L = I.convert('L')
#     a = np.array(L)
#     image = np.expand_dims(a, axis=2)
#     image = np.concatenate((image, image, image), axis=-1)
#     cv2.imwrite(out_dir + i, image)

import cv2
import os
from PIL import Image
import numpy as np
file_dir = 'E:/核辐射检测/放射源搜寻第二篇论文撰写/能量沉积/37000000粒子/0.5m/'    #'输入文件夹/'
out_dir = 'E:/dataset_test/'    #'输出文件夹/' 注意：读出必须是英文路径，否则无法导出
a = os.listdir(file_dir)
# img = Image.open("home/img/Image_01.jpg")  #单个图像打开方法

for i in a:
    print(i)
    I = Image.open(file_dir + i)
    L = I.convert('L')
    a= np.array(L) # 转化成numpy数组
    image = np.expand_dims(a, axis=2)
    image = np.concatenate((image, image, image), axis=-1)  # axis=-1就是最后一个通道
    #image.save(out_dir + i)        #保存图片（将图像保存成图像）
    cv2.imwrite(out_dir + i, image)  # 保存图片（将数组保存成图像）
    # print(image)
