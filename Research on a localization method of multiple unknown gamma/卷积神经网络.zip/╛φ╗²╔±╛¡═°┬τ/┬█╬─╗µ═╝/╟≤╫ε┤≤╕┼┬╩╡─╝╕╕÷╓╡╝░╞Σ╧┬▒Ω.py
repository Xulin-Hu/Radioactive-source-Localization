import heapq

arr1 = [[20,100,2,3,1,0,1000,156,30,7],
       [30,500,2,3,1,0,5000,156,50,7],
       [20,80,2,3,1,0,500,196,30,7],]

for i in [0,1,2]:   #range(3)=[0,1,2]
    arr = arr1[i]
    ##求最大的5个值
    arr_max = heapq.nlargest(3, arr)  # 获取前3大的值并排序
    index_max = map(arr.index, arr_max)  # 获取前3大的值下标
    print(arr_max)
    # print(index_max)
    a = list(index_max)  # map生成的对象要转化成为list才能输出
    print(a)
    # print(a[0])
    print(arr[a[0]], arr[a[1]], arr[a[2]])  # 得到数组的最大值及预测便签、及对应的真实值标签0
