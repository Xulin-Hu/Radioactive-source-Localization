import numpy as np
import pandas as pd
x=[[1,2,4,5],[1,2,4,5]]
df = pd.DataFrame(x)
df.to_csv('E:/核辐射检测/放射源搜寻第二篇论文撰写/energy_deposite_tf2.3-CNN/results/网络预测结果.csv',index= False, header= False)
# 不要头文件，不要列索引
# df1 = pd.read_csv('E:/核辐射检测/放射源搜寻第二篇论文撰写/energy_deposite_tf2.3-CNN/网络预测结果.csv',header=None)
