import matplotlib.pyplot as plt  # 绘图导入
plt.figure(figsize=(8, 8))
plt.subplot(2, 1, 1)
acc = [0.31, 0.51, 0.648, 0.742, 0.791, 0.821, 0.851, 0.865]
val_acc = [0.1, 0.4, 0.9, 0.1, 0.1, 0.3, 0.1,0.31, 0.51, 0.648, 0.742, 0.7]

font2 = {'family': 'Arial',
 'weight': 'normal',
 'size': 12,
}  # 设置图片字体大小

plt.plot(acc, label='Training Accuracy', marker="o", color='r')  # markersize=4表示标记点的大小
plt.plot(val_acc, label='Validation Accuracy', marker=">", color='g')
plt.legend(loc='lower right')
plt.ylabel('Accuracy', font2)
plt.ylim([min(plt.ylim()), 1])
plt.xlabel('Epoch', font2)
# plt.title('Training and Validation Accuracy')
loss = [0.31, 0.51, 0.648, 0.742, 0.791, 0.821, 0.851, 0.865]
val_loss = [0.1, 0.4, 0.9, 0.1, 0.1, 0.3, 0.1, 0.31, 0.51, 0.648]
plt.subplot(2, 1, 2)
plt.plot(loss, label='Training Loss', marker="o", color='r')
plt.plot(val_loss, label='Validation Loss', marker=">", color='g')
plt.legend(loc='upper left')
plt.ylabel('Loss', font2)
plt.xlabel('Epoch', font2)
plt.show()