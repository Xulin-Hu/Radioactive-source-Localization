import csv
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt
from scipy import misc
import cv2
import os

def get_files(path='E:/核辐射检测/放射源搜寻第二篇论文撰写/能量沉积/37000000粒子/0.5m/', rule=".csv"):
    for fpathe, dirs, fs in os.walk(path):   # os.walk获取所有的目录
        for f in fs:
            filename = os.path.join(fpathe, f)
            if filename.endswith(rule):  # 判断是否是".csv"结尾
                with open(filename, encoding='UTF-8-sig') as csvfile:  #打开文件
                    list = np.loadtxt(csvfile, delimiter=",", skiprows=0)  #获取文件内的数据
                    img = Image.fromarray(np.uint8(list))
                    img.save(filename.replace(".csv", ".bmp"))

get_files()


