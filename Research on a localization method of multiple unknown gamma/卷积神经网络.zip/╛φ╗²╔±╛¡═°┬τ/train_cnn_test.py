# -*- coding: utf-8 -*-
# @Time    : 2021/6/17 20:29
# @Author  : dejahu
# @Email   : 1148392984@qq.com
# @File    : train_cnn.py
# @Software: PyCharm
# @Brief   : cnn模型训练代码，训练的代码会保存在models目录下，折线图会保存在results目录下

import tensorflow as tf
import matplotlib.pyplot as plt  # 导入绘图库plot
from time import *


# 数据集加载函数，指明数据集的位置并统一处理为imgheight*imgwidth的大小，同时设置batch
def data_load(data_dir, test_data_dir, img_height, img_width, batch_size): #输入训练集目录、测试集目录
    # 加载训练集
    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        data_dir,
        label_mode='categorical',
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size,
        color_mode="grayscale")  # grayscale为灰度图像，默认为RGB
    # 加载测试集
    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        test_data_dir,
        label_mode='categorical',
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size,
        color_mode="grayscale") # grayscale为灰度图像，默认为RGB
    class_names = train_ds.class_names
    # 返回处理之后的训练集、验证集和类名
    return train_ds, val_ds, class_names


# 构建CNN模型
def model_load(class_num=10):  #class_num指分类的数量，会自动读取
    # 搭建模型
    model = tf.keras.models.Sequential([
        # 对模型做归一化的处理，将0-255之间的数字统一处理到0到1之间 #将0-255的像素值处理到0-1的之间
        tf.keras.layers.experimental.preprocessing.Rescaling(1. / 255, input_shape=(40, 40, 1)),
        # 卷积层，该卷积层的输出为64个通道，卷积核的大小是2*2，激活函数为relu
        tf.keras.layers.Conv2D(64, (2, 2), activation='relu'),
        # 卷积层，输出为128个通道，卷积核大小为2*2，激活函数为relu
        tf.keras.layers.Conv2D(128, (2, 2), activation='relu'),
        # 卷积层，输出为128个通道，卷积核大小为2*2，激活函数为relu
        tf.keras.layers.Conv2D(128, (2, 2), activation='relu'),
        # 将二维的输出转化为一维
        tf.keras.layers.Flatten(),
        # The same 128 dense layers, and 10 output layers as in the pre-convolution example:
        tf.keras.layers.Dense(128, activation='relu'),
        # 通过softmax函数将模型输出为类名长度的神经元上，激活函数采用softmax对应概率值
        tf.keras.layers.Dense(class_num, activation='softmax')
    ])
    # model = tf.keras.models.Sequential([
    #     tf.keras.layers.Conv2D(filters=6, kernel_size=(5, 5), padding='valid', activation=tf.nn.relu,
    #                            input_shape=(40, 40, 1)),
    #     # relu
    #     tf.keras.layers.AveragePooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'),
    #     tf.keras.layers.Conv2D(filters=16, kernel_size=(5, 5), padding='valid', activation=tf.nn.relu),
    #     tf.keras.layers.AveragePooling2D(pool_size=(2, 2), strides=(2, 2), padding='same'),
    #     tf.keras.layers.Flatten(),
    #     tf.keras.layers.Dense(units=120, activation=tf.nn.relu),
    #
    #     tf.keras.layers.Dense(units=84, activation=tf.nn.relu),
    #     tf.keras.layers.Dense(units=10, activation=tf.nn.softmax)
    # ])
    # 输出模型信息
    model.summary()
    # 指明模型的训练参数，优化器为sgd优化器，损失函数为交叉熵损失函数 sgd优化器表示随机梯度下降
    model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
    # 返回模型
    return model


# 展示训练过程的曲线
def show_loss_acc(history):
    # 从history中提取模型训练集和验证集准确率信息和误差信息
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    # 按照上下结构将图画输出
    plt.figure(figsize=(8, 8))
    plt.subplot(2, 1, 1)  # 划分子图
    plt.plot(acc, label='Training Accuracy')  # 标签设置
    plt.plot(val_acc, label='Validation Accuracy')  # 标签设置
    plt.legend(loc='lower right')
    plt.ylabel('Accuracy')
    plt.ylim([min(plt.ylim()), 1])
    plt.title('Training and Validation Accuracy')  # 添加子标题

    plt.subplot(2, 1, 2)  # 划分子图
    plt.plot(loss, label='Training Loss')  # 标签设置
    plt.plot(val_loss, label='Validation Loss')  # 标签设置
    plt.legend(loc='upper right')
    plt.ylabel('Cross Entropy')
    plt.title('Training and Validation Loss')    # 添加子标题
    plt.xlabel('epoch')
    plt.savefig('results/results_cnn.png', dpi=100)


def train(epochs):
    # 开始训练，记录开始时间
    begin_time = time()
    # todo 加载数据集， 修改为你的数据集的路径
    train_ds, val_ds, class_names = data_load("E:/核辐射检测/能量沉积/划分好的数据集进行训练/1~10每组4000数据/train",  # 训练集路径
                                              "E:/核辐射检测/能量沉积/划分好的数据集进行训练/1~10每组4000数据/val", 40, 40, 16)  # 验证集路径
    print(class_names)
    # 加载模型
    model = model_load(class_num=len(class_names))
    # 指明训练的轮数epoch，开始训练
    history = model.fit(train_ds, validation_data=val_ds, epochs=epochs)
    # todo 保存模型， 修改为你要保存的模型的名称
    model.save("models/cnn_flowers.h5")
    # 记录结束时间
    end_time = time()
    run_time = end_time - begin_time
    print('该循环程序运行时间：', run_time, "s")  # 该循环程序运行时间： 1.4201874732
    # 绘制模型训练过程图
    show_loss_acc(history)


if __name__ == '__main__':
    train(epochs=10) #轮数设置