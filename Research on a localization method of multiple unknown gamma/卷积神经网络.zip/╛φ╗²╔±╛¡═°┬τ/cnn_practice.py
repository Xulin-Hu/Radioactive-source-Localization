import tensorflow as tf
import matplotlib.pyplot as plt
from time import *
# 加载图像
def data_load(data_dir,test_data_dir,img_height,img_width,batch_size):
    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        data_dir,
        label_mode='categorical',
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size
    )
    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        test_data_dir,
        label_mode='categorical',
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size
    )
    class_names = train_ds.class_names  # 读取类名
    return train_ds, val_ds, class_names

def model_load(IMG_SHAPE = (224, 224, 3) ,class_num=10):

    # 搭建模型
    model = tf.keras.models.Sequential([
        # 先对模型进行归一化
        tf.keras.layers.experimental.preprocessing.Rescaling(1./255, input_shape=IMG_SHAPE),
        # 卷积层
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu'),
        # 池化层
        tf.keras.layers.MaxPool2D(2, 2),
        # 再卷积
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
        # 再池化
        tf.keras.layers.MaxPool2D(2, 2),
        # 将输出二维结果拉伸为一维
        tf.keras.layers.Flatten(),
        # The same 128 dense layers, and 10 output layers as in the pre-convolution example:
        tf.keras.layers.Dense(128, activation='relu'),  # 输入全连接层，第一层输出128个节点
        tf.keras.layers.Dense(class_num, activation='softmax')  # 输入到第二层全连接层，输出为10个节点
    ])
    # 指明模型的训练参数，优化器为sgd优化器，损失函数为交叉熵损失函数 sgd优化器表示随机梯度下降
    model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])
    print(model.summary())  # 使用keras构建深度学习模型，通过model.summary()输出模型中各层的参数状况
    return model  # 返回模型

# 展示训练过程的曲线
def show_loss_acc(history):
    # 从history中提取模型训练集和验证集准确率信息和误差信息
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']
    # 按上下结构将图画输出
    plt.figure(figsize=(8, 8))
    plt.subplot(2, 1, 1)
    plt.plot(acc, label='Training Accuracy')
    plt.plot(val_acc, label='Validation Accuracy')
    plt.legend(loc='lower right')
    plt.ylabel('Accuracy')
    plt.ylim([min(plt.ylim()), 1])
    plt.title('Training and Validation Accuracy')

    plt.subplot(2, 1, 2)
    plt.plot(loss, label='Training Loss')
    plt.plot(val_loss, label='Validation Loss')
    plt.legend(loc='upper right')
    plt.ylabel('Cross Entropy')
    plt.title('Training and Validation Loss')
    plt.xlabel('epoch')
    plt.savefig('results/results_cnn.png', dpi=100)

def train(epochs):
    begin_time = time()  # 开始训练，记录开始时间
    # 读入训练和验证路径
    train_ds, val_ds, class_names = data_load('E:/卷积神经网络/new_data/train',
                                              'E:/卷积神经网络/new_data/val', 224, 224, 16)
    # print(train_ds, val_ds)  # 打印训练集和验证集
    # print(class_names)       # 打印类名
    # 加载CNN模型
    model = model_load(class_num=len(class_names))  # 输入类的长度到CNN模型
    history = model.fit(train_ds, validation_data=val_ds, epochs=epochs)  # 训练集、验证集、轮数，记录训练信息
    model.save("models/cnn_flowers.h5")  # 保存模型：name
    end_time = time()  # 记录结束时间
    run_time = end_time - begin_time  # 程序运行的总时间
    print("总的循环时间为：", run_time, "s")  # 打印程序运行总时间
    show_loss_acc(history)  # 绘制模型训练过程图

if __name__ == '__main__':
    train(epochs=1)  # 设置训练轮数
