# @File    : train_cnn.py
# @Software: PyCharm
# @Brief   : cnn模型训练代码，训练的代码会保存在models目录下，折线图会保存在results目录下

import tensorflow as tf
import matplotlib.pyplot as plt  # 绘图导入
from time import *
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"#指定在第0块GPU上跑
# 数据集加载函数，指明数据集的位置并统一处理为imgheight*imgwidth的大小，同时设置batch，batch设置为16 32 64更好（2的幂次）
def data_load(data_dir, test_data_dir, img_height, img_width, batch_size): #输入训练集目录、测试集目录
    #定义数据加载函数data_load，data_dir为训练集路径，test_data_dir为验证集路径
    #img_height为图片的高度，img_width为图片的宽度，batch_size为一次训练所选取的样本数
    # 加载训练集
    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        data_dir,
        label_mode='categorical',  # ‘categorical’指标签被编码为分类向量
        seed=123,  # 当在代码中使用了随机数，但是希望代码在不同时间或者不同的机器上运行能够得到相同的随机数，以至于能够得到相同的结果，那么就需要到设置随机函数的seed 参数
        image_size=(img_height, img_width),  # 读取数据后会自动调整大小为img_height、img_width尺寸
        batch_size=batch_size)  # 数据批次的大小。默认值：32
    # 加载测试集
    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        test_data_dir,
        label_mode='categorical',
        seed=123,
        image_size=(img_height, img_width),
        batch_size=batch_size)
    class_names = train_ds.class_names   #读取类名
    # 返回处理之后的训练集、验证集和类名
    return train_ds, val_ds, class_names


# 构建CNN模型               #IMG_SHAPE为20*20*1
def model_load(IMG_SHAPE=(40,40,3), class_num=165):   #class_num指分类的数量，会自动读取
    # 搭建模型
    model = tf.keras.models.Sequential([
        # 对模型做归一化的处理，将0-255之间的数字统一处理到0到1之间 #将0-255的像素值处理到0-1的之间
        tf.keras.layers.experimental.preprocessing.Rescaling(1. / 255, input_shape=IMG_SHAPE),
        # 卷积层，该卷积层的输出为32个通道，卷积核的大小是3*3，激活函数为relu
        tf.keras.layers.Conv2D(32, (3, 3), activation='relu'),  # 一般卷积核的大小都是选取3*3
        # Add another convolution
        # 卷积层，输出为64个通道，卷积核大小为3*3，激活函数为relu
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
        # 卷积层，输出为64个通道，卷积核大小为3*3，激活函数为relu
        tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
        # # # 池化层，最大池化，对2*2的区域进行池化操作
        # tf.keras.layers.MaxPooling2D(2, 2),
        # 将二维的输出转化为一维
        tf.keras.layers.Flatten(),
        # The same 128 dense layers, and 10 output layers as in the pre-convolution example:
        tf.keras.layers.Dense(800, activation='relu'),
        tf.keras.layers.Dense(200, activation='relu'),
        # 通过softmax函数将模型输出为类名长度的神经元上，激活函数采用softmax对应概率值
        tf.keras.layers.Dense(class_num, activation='softmax')
    ])
    # 输出模型信息
    model.summary()
    # 指明模型的训练参数，优化器为sgd优化器，损失函数为交叉熵损失函数 sgd优化器表示随机梯度下降
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])  # 优化器为adam、sgd、RMSprop 常用的优化器有梯度下降：GradientDescent，Momentum，自适应学习率算法：Adagrad，RMSProp，Adam
    # 返回模型
    return model



# 展示训练过程的曲线
def show_loss_acc(history):
    # 从history中提取模型训练集和验证集准确率信息和误差信息
    acc = history.history['accuracy']
    val_acc = history.history['val_accuracy']
    loss = history.history['loss']
    val_loss = history.history['val_loss']

    # 按照上下结构将图画输出
    plt.figure(figsize=(8, 8))
    plt.subplot(2, 1, 1)
    plt.plot(acc, label='Training Accuracy', marker="o", color='r')    # markersize=4表示标记点的大小
    plt.plot(val_acc, label='Validation Accuracy', marker="^", color='g')
    plt.legend(loc='lower right')
    plt.ylabel('Accuracy')
    plt.ylim([min(plt.ylim()), 1])
    plt.xlabel('epoch')
    # plt.title('Training and Validation Accuracy')

    plt.subplot(2, 1, 2)
    plt.plot(loss, label='Training Loss', marker="o", color='r')
    plt.plot(val_loss, label='Validation Loss', marker="^", color='g')
    plt.legend(loc='upper right')
    plt.ylabel('Loss')
    plt.xlabel('epoch')
    plt.savefig('results/results_cnn.png', dpi=600)


def train(epochs):
    # 开始训练，记录开始时间
    begin_time = time()
    # todo 加载数据集， 修改为你的数据集的路径
    #得到的train_ds=训练集、val_ds=验证集和class_names=类名，图片的高度为224，宽度为224，选取的样本数batch_size为16
    train_ds, val_ds, class_names = data_load("C:/Users/胡/Desktop/肿瘤识别/data/train",  # 训练集路径
                                              "C:/Users/胡/Desktop/肿瘤识别/data/val", 40, 40, 16)  # 验证集路径
    print(class_names)
    # 加载模型
    model = model_load(class_num=len(class_names))
    # 指明训练的轮数epoch，开始训练
    history = model.fit(train_ds, validation_data=val_ds, epochs=epochs)
    # todo 保存模型， 修改为你要保存的模型的名称
    model.save("models/cnn_search radioactive source.h5")
    # 记录结束时间
    end_time = time()
    run_time = end_time - begin_time
    print('该循环程序运行时间：', run_time, "s")  # 该循环程序运行时间： 1.4201874732
    # 绘制模型训练过程图
    show_loss_acc(history)


if __name__ == '__main__':
    train(epochs=25)  # 轮数设置


