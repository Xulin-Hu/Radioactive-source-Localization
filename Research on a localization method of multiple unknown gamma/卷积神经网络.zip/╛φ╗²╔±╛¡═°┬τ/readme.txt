1.python配置：
tensorflow-cpu==2.1.0
pyqt5
pillow
opencv-python
matplotlib
2.CNN神经网络采用已有算法进行修改，详情请查阅readme.md文件内的内容
3.依次运行CSV转灰度图、灰度图转三通道、将图片分类到对应文件夹、data_split、train_cnn.py、test_model