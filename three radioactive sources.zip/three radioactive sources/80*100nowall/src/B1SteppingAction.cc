//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file B1SteppingAction.cc
/// \brief Implementation of the B1SteppingAction class

#include "B1SteppingAction.hh"
#include "B1EventAction.hh"
#include "B1DetectorConstruction.hh"
#include "G4Step.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"
#include "G4SystemOfUnits.hh"

G4double PositionY;
G4double PositionZ;
G4double PositionX;


extern G4double xz_1[80][100] = {0};
extern G4double xz_2[80][100] = {0};
extern G4double xz_3[80][100] = {0};
G4double distance = 100.0 * mm;        //定义分割的间隔（Geant4默认长度单位为mm）
G4double edepStep;
G4double thcikness, height_1,height_2,height_3;//定义厚度和高度

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1SteppingAction::B1SteppingAction(B1EventAction *eventAction)
    : G4UserSteppingAction(),
      fEventAction(eventAction),
      fScoringVolume(0)
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1SteppingAction::~B1SteppingAction()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void B1SteppingAction::UserSteppingAction(const G4Step *step)
{
  //得到坐标数据
  PositionY = step->GetTrack()->GetPosition().getY() / mm;
  PositionZ = step->GetTrack()->GetPosition().getZ() / mm;
  PositionX = step->GetTrack()->GetPosition().getX() / mm;
  // collect energy deposited in this step
  edepStep = step->GetTotalEnergyDeposit();
  // G4cout << PositionY << " " << PositionZ<< G4endl;
    height_1 = -4500 * mm;           //离地1m
    height_2= -4000*mm;         //离地0.5m
    height_3= -3500*mm;         //离地1.5m
    thcikness = (100 / 2) * mm; //厚度

    //导出二维数据 XZ面,离地0.5m
    if ((PositionY > height_1 - thcikness) && (PositionY < height_1 + thcikness))
    {
        for (int i = 0; i < 80; i++)
        {
            if ((PositionZ > -4000 * mm + i*distance) && (PositionZ < (-4000 * mm + distance * (i + 1))))
            {
                for (int j = 0; j < 100; j++)
                {
                    if ((PositionX > -5000 * mm + j*distance) && (PositionX < (-5000 * mm + distance * (j + 1))))
                    {
                        xz_1[i][j] = xz_1[i][j] + edepStep;
                    }
                }
            }
        }
    }
    //导出二维数据 XZ面,离地1m
    if ((PositionY > height_2 - thcikness) && (PositionY < height_2 + thcikness))
    {
        for (int i = 0; i < 80; i++)
        {
            if ((PositionZ > -4000 * mm + i*distance) && (PositionZ < (-4000 * mm + distance * (i + 1))))
            {
                for (int j = 0; j < 100; j++)
                {
                    if ((PositionX > -5000 * mm + j*distance) && (PositionX < (-5000 * mm + distance * (j + 1))))
                    {
                        xz_2[i][j] = xz_2[i][j] + edepStep;
                    }
                }
            }
        }
    }
    //导出二维数据 XZ面,离地1.5m
    if ((PositionY > height_3 - thcikness) && (PositionY < height_3 + thcikness))
    {
        for (int i = 0; i < 80; i++)
        {
            if ((PositionZ > -4000 * mm + i*distance) && (PositionZ < (-4000 * mm + distance * (i + 1))))
            {
                for (int j = 0; j < 100; j++)
                {
                    if ((PositionX > -5000 * mm + j*distance) && (PositionX < (-5000 * mm + distance * (j + 1))))
                    {
                        xz_3[i][j] = xz_3[i][j] + edepStep;
                    }
                }
            }
        }
    }

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
