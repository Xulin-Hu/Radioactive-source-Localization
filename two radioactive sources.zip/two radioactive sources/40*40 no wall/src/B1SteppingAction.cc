//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
/// \file B1SteppingAction.cc
/// \brief Implementation of the B1SteppingAction class

#include "B1SteppingAction.hh"
#include "B1EventAction.hh"
#include "B1DetectorConstruction.hh"
#include "G4Step.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"
#include "G4SystemOfUnits.hh"

G4double PositionY;
G4double PositionZ;
G4double PositionX;
extern G4double xy[40][40] = {0}; //定义全局记录数组  //to do
extern G4double xz[40][40] = {0};
extern G4double yz[40][40] = {0};
G4double distance = 250.0 * mm;        //定义分割的间隔（Geant4默认长度单位为mm）
G4double edepStep;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1SteppingAction::B1SteppingAction(B1EventAction *eventAction)
    : G4UserSteppingAction(),
      fEventAction(eventAction),
      fScoringVolume(0)
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1SteppingAction::~B1SteppingAction()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void B1SteppingAction::UserSteppingAction(const G4Step *step)
{
  //得到坐标数据
  PositionY = step->GetTrack()->GetPosition().getY() / mm;
  PositionZ = step->GetTrack()->GetPosition().getZ() / mm;
  PositionX = step->GetTrack()->GetPosition().getX() / mm;
  // collect energy deposited in this step
  edepStep = step->GetTotalEnergyDeposit();
  // G4cout << PositionY << " " << PositionZ<< G4endl;

  //导出二维数据 XY面
  for (int i = 0; i < 40; i++)  //
  {
    if ((PositionY > -5000 * mm + i*distance) && (PositionY < (-5000 * mm + distance * (i + 1))))
    {
      for (int j = 0; j < 40; j++) //
      {
        if ((PositionX > -5000 * mm + j*distance) && (PositionX < (-5000 * mm + distance * (j + 1))))
        {
          xy[i][j] = xy[i][j] + edepStep;
        }
      }
    }
  }

  //导出二维数据 XZ面
  for (int i = 0; i < 40; i++)
  {
    if ((PositionZ > -5000 * mm + i*distance) && (PositionZ < (-5000 * mm + distance * (i + 1))))
    {
      for (int j = 0; j < 40; j++)
      {
        if ((PositionX > -5000 * mm + j*distance) && (PositionX < (-5000 * mm + distance * (j + 1))))
        {
          xz[i][j] = xz[i][j] + edepStep;
        }
      }
    }
  }

  //导出二维数据 YZ面
  for (int i = 0; i < 40; i++)
  {
    if ((PositionZ > -5000 * mm + i*distance) && (PositionZ < (-5000 * mm + distance * (i + 1))))
    {
      for (int j = 0; j < 40; j++)
      {
        if ((PositionY > -5000 * mm + j*distance) && (PositionY < (-5000 * mm + distance * (j + 1))))
        {
          yz[i][j] = yz[i][j] + edepStep;
        }
      }
    }
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
